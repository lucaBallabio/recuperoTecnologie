/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esverifica2;

/**
 *
 * @author balla
 */
public class Semaphore {
    /** contatore del semaforo **/
    int valore;

    /**
     * @brief costruttore con parametro che inizializza il contatore del semaforo
     * 
     * @param n intero che rappresenta il valore con cui inizializzare il semaforo 
     */
    public Semaphore(int n) {
        valore = n;
    }

    synchronized public void Wait() {
        while (valore == 0) {            
            try {
                wait();
            } 
            catch (InterruptedException e) {
            }
        }
        valore--;                          
    } 
    synchronized public void Signal() {
        valore++;                          
        notify();                          
    }
}
