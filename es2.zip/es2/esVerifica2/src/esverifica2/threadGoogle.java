/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esverifica2;

/**
 *
 * @author balla
 */
public class threadGoogle extends Thread{
     datiCondivisi datiCon;
     String cerca = datiCon.getStr();
     String[] elenco = datiCon.getElencoGOOGLE();
    
    public threadGoogle(){
        datiCon = new datiCondivisi();
    }
    
    public void run(){
        
        datiCon.waitSem2();
        datiCon.svuotaVett();
        for(int i=0; i<elenco.length;i++){
            if(elenco[i].contains(cerca))
                datiCon.addVett(elenco[i]);
        }
        datiCon.signalSem3();
    }
}
