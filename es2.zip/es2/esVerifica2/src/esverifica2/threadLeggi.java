/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esverifica2;

import java.util.Scanner;

/**
 *
 * @author balla
 */
public class threadLeggi extends Thread{
    datiCondivisi datiCon;
    
    public threadLeggi(){
        datiCon = new datiCondivisi();
    }
    
    Scanner scanner = new Scanner(System.in);
    String s = scanner.nextLine();
    datiCon.waitSem1();
    datiCon.setStr(s);
    datiCon.signalSem2();
}
