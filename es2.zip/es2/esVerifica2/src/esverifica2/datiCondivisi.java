/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esverifica2;

/**
 *
 * @author balla
 */
public class datiCondivisi {

    private String[] elencoGOOGLE = {"agora.ismonnet.it", "www.google.com", "github.com", "www.ismonnet.gov.it", "github.com/giodabg"};
    private String[] elencoCACHE = {"https://www.html.it/pag/50430/gli-array-injava", "www.html.it",
            "https://www.ismonnet.gov.it", "github.com/giodabg/EseThread", "https://www.ismonnet.gov.it/circolari.asp?bld=doc"}; 
    private String[] elencoElementiTrovati;
    private String str;
    private int numEl;
    
    Semaphore sem1,sem2,sem3,sem4;

    public datiCondivisi() {
        this.str= "";
        this.numEl=0;
        sem1=new Semaphore(1);
        sem2=new Semaphore(0);
        sem3=new Semaphore(0);
        sem4=new Semaphore(0);
    }
    
    public void addVett(String s){
        this.elencoElementiTrovati[numEl]=s;
        numEl++;
    }
    
    public void svuotaVett(){
        this.elencoElementiTrovati = null;
    }
    
    public void setStr(String s){
        str += s;
    }
    
    public String getStr(){
        return str;
    }
    
    public void visualizzaVett(){
        for(int i=0; i< elencoElementiTrovati.length; i++){
            System.out.println(elencoElementiTrovati[i]);
        }
    }
    
    public String[] getElencoGOOGLE(){
        return elencoGOOGLE;
    }
    
    public String[] getElencoCACHE(){
        return elencoCACHE;
    }
    
    public void waitSem1(){
        sem1.Wait();
    }
    
    public void signalSem1(){
        sem1.Signal();
    }
    
    public void waitSem2(){
        sem2.Wait();
    }
    
    public void signalSem2(){
        sem2.Signal();
    }
    
    public void waitSem3(){
        sem3.Wait();
    }
    
    public void signalSem3(){
        sem3.Signal();
    }
    
    public void waitSem4(){
        sem4.Wait();
    }
    
    public void signalSem4(){
        sem4.Signal();
    }
}

