/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esverifica2;

/**
 *
 * @author balla
 */
public class threadVett extends Thread{
    datiCondivisi datiCon;
    
    public threadVett(){
        datiCon = new datiCondivisi();
    }
    
    public void run(){
        datiCon.waitSem4();
        datiCon.visualizzaVett();
        datiCon.signalSem1();
    }
}
