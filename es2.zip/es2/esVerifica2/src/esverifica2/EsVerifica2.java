/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esverifica2;

/**
 *
 * @author balla
 */

/*
ANALISI

- grado di parallelismo -> 5 (4 thread)
- il main intergisce con l'utente
- chiedere all'utente una stringa contenente il nome del link che si sta cercando
- il primo thread ha il compito di verificare l'input
- il secondo thread cerca la stringa dell'utente all'interno del vettore contenente 
i link di google
- il terzo thread cerca la stringa dell'utente all'interno del vettore contenente 
i link della cache
- il quarto thread visualizza un vettore contenente tutti i link trovati all'interno
dei vettori elencoGOOGLE e elencoCACHE


*/
public class EsVerifica2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        
    }
    
}
