/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esverifica1;

/**
 *
 * @author balla
 */
public class threadManichini extends Thread{
    
    int nThread;
    datiCondivisi datiCon;
    
    public threadManichini(){
        this.nThread=0;
    }
    
    public threadManichini(int nThread){
        this.nThread=nThread;
    }
    
    public void run(int nThread){
        if(nThread == 1){
            
            datiCon.waitMutex1();
            System.out.println("manichino 1 partito");
            datiCon.signalMutex2();
        }else{
            datiCon.waitMutex2();
            System.out.println("manichino 2 partito");
            datiCon.signalMutex3();
        }
    }
}
