/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esverifica1;

/**
 *
 * @author balla
 */
public class threadCani extends Thread{
    int nThread;
    datiCondivisi datiCon;
    
     public threadCani(){
        this.nThread=0;
    }
    
    public threadCani(int nThread){
        this.nThread=nThread;
    }
    
    public void run(int nThread) throws InterruptedException{
        if(nThread == 1){
            datiCon.waitMutex3();
            System.out.println("Attesa.........");
            int random=(int)Math.random()*10;
            random++;
            threadCani.sleep(random);
            System.out.println("cane 1 prende manichino 1");
            datiCon.signalMutex4();
            
        }else{
            datiCon.waitMutex4();
            System.out.println("Attesa.........");
            int random=(int)Math.random()*10;
            random++;
            threadCani.sleep(random);
            System.out.println("cane 2 prende manichino 2");
            datiCon.signalMutex1();
        }
    }
}
