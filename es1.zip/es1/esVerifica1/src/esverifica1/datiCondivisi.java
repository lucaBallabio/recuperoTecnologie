/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esverifica1;

/**
 *
 * @author balla
 */
public class datiCondivisi {
    Semaphore mutex1;
    Semaphore mutex2;
    
    public datiCondivisi(){
        Semaphore mutex1 = new Semaphore(0);
        Semaphore mutex2 = new Semaphore(0);
    }
    
    public void waitMutex1(){
        mutex1.Wait();
    }
    
    public void signalMutex1(){
        mutex1.Signal();
    }
    
     public void waitMutex2(){
        mutex2.Wait();
    }
    
    public void signalMutex2(){
        mutex2.Signal();
    }
}
