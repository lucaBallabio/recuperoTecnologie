/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esverifica1;

import java.util.Scanner;

/**
 *
 * @author balla
 */
public class EsVerifica1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        // TODO code application logic here
        datiCondivisi datiCon;

        Scanner scanner = new Scanner(System.in);
        System.out.println("inserire S per far partire i manichini e i cani");
        String s = scanner.nextLine();

        threadManichini thManichini1 = new threadManichini(1);
        threadManichini thManichini2 = new threadManichini(2);
        threadCani thCani1 = new threadCani(1);
        threadCani thCani2 = new threadCani(2);

        while (s == "S") {

            thManichini1.start();
            thManichini2.start();
            thCani1.start();
            thCani2.start();

            thManichini1.join();
            thManichini2.join();
            thCani1.join();
            thCani2.join();
            
            System.out.println("per continuare il programma scrivere -> S , per terminare scrivere -> F");
            
            s = scanner.nextLine();
        }
    }

}
